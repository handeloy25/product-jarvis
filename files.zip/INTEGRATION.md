# Expert Personas Integration Guide

This guide explains how to add the Expert Review Board to your existing Product Jarvis installation.

## Quick Start (5 minutes)

### Step 1: Add Backend Router

Copy `backend/routers/personas.py` to your project's `backend/routers/` directory.

Then add the router to your `main.py`:

```python
# In backend/main.py

from routers import personas  # Add this import

# Add this with your other router includes
app.include_router(personas.router, prefix="/api")
```

### Step 2: Add Frontend Page

Copy `frontend/src/pages/ExpertReview.jsx` to your project's `frontend/src/pages/` directory.

### Step 3: Add Route

In your React router configuration (likely `App.jsx` or `routes.jsx`):

```jsx
import ExpertReview from './pages/ExpertReview';

// Add to your routes
<Route path="/expert-review" element={<ExpertReview />} />
```

### Step 4: Add Navigation

Add a link to your navigation menu:

```jsx
<NavLink to="/expert-review" icon={Users}>
  Expert Review
</NavLink>
```

### Step 5: Restart Services

```bash
# Terminal 1 - Backend
cd backend && source venv/bin/activate && uvicorn main:app --reload --port 8000

# Terminal 2 - Frontend  
cd frontend && npm run dev
```

---

## Using Expert Review

### Quick Commands

From anywhere in Product Jarvis, you can trigger expert reviews. Here are the common patterns:

| Command | What Happens |
|---------|--------------|
| "Have Alex review the architecture" | Dr. Chen evaluates system design |
| "Elena, check the UX" | Rodriguez audits user experience |
| "Full board review" | All 6 experts provide comprehensive assessment |
| "Sarah, is this feature worth building?" | Kim evaluates product strategy |
| "Marcus, reality check this timeline" | Thompson assesses schedule feasibility |
| "Jordan, how's our deployment setup?" | Martinez reviews DevOps |
| "David, is our data model right?" | Park evaluates analytics architecture |

### Pre-Built Quick Reviews

| Review Type | Experts Involved | Best For |
|-------------|------------------|----------|
| Architecture Review | Dr. Chen | Major technical decisions |
| UX Audit | Elena Rodriguez | Before user testing |
| Product Strategy Check | Sarah Kim | Feature prioritization |
| Timeline Reality Check | Marcus Thompson | Sprint planning |
| Full Board Review | All 6 experts | Major milestones, releases |
| Pre-Release Review | Jordan + Marcus + Elena | Before deployment |

---

## Integrating with Your Workflow

### Before Major Changes

Before implementing significant changes like your upcoming enhancements (overhead costs, service tracking, reports), run a **Product Strategy Check** with Sarah Kim and a **Timeline Reality Check** with Marcus Thompson.

Example flow:
1. Document proposed changes in the context field
2. Select Sarah Kim + Marcus Thompson
3. Set scope to "Proposed Changes"
4. Run evaluation
5. Address concerns before coding

### During Development

Periodically run targeted reviews:
- After completing major features: **Architecture Review**
- After UI changes: **UX Audit**
- After adding new data models: Have David Park review

### Before Releases

Run **Pre-Release Review** (Jordan + Marcus + Elena) to catch:
- Deployment risks
- Missing edge cases
- UX issues

---

## Customizing Personas

### Adding a New Persona

1. Edit `backend/routers/personas.py`
2. Add to the `PERSONAS` dictionary:

```python
"new_expert": ExpertPersona(
    id="new_expert",
    name="Expert Name",
    title="Their Title",
    background="Their background...",
    expertise=["Area 1", "Area 2", "Area 3"],
    evaluation_style="How they evaluate...",
    key_questions=["Question 1?", "Question 2?"],
    icon="icon-name",  # From lucide-react
    color="blue"  # blue, green, purple, orange, pink, cyan
)
```

3. The frontend will automatically pick up new personas

### Modifying Existing Personas

Edit the persona definition in `PERSONAS` dictionary. Changes take effect immediately on server restart.

### Changing Evaluation Output Format

Edit the prompt templates in the `build_evaluation_prompt()` function.

---

## API Reference

### GET /api/personas/
Returns list of all available personas.

### GET /api/personas/{persona_id}
Returns detailed information about a specific persona.

### POST /api/personas/build-prompt
Generates the evaluation system prompt.

**Request Body:**
```json
{
  "persona_ids": ["alex_chen", "sarah_kim"],
  "scope": "current_state",
  "context": "Your context here...",
  "specific_questions": ["Question 1?", "Question 2?"],
  "include_checkpoint": true,
  "include_documentation": false
}
```

### GET /api/personas/quick-prompts
Returns pre-built quick evaluation configurations.

---

## Using with External Claude

If you want to use the personas with Claude directly (not through the built-in assistant):

1. Generate the prompt using the "Generate Prompt" button
2. Copy the system prompt
3. Open Claude (claude.ai or API)
4. Paste the system prompt as your first message or system instructions
5. Then paste your context for evaluation

This is useful for longer conversations or when you want to iterate on feedback.

---

## Troubleshooting

### Personas not loading
- Check that the router is properly included in `main.py`
- Verify the API is running: `curl http://localhost:8000/api/personas/`

### Evaluation not running
- Ensure your existing assistant endpoint is working
- Check browser console for API errors

### Prompt too long
- Reduce context to essential information
- Use specific feature scope instead of full codebase
- Select fewer experts for faster evaluation
